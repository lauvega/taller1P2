
package com.mycompany.sistemabancario;


class CapacidadExcedidaException {
    
}
