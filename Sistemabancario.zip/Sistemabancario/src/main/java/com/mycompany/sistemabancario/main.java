package com.mycompany.sistemaBancario;

import modelo.abstractas.Cuenta;
import java.time.LocalDate;
import java.util.Scanner;
import modelo.banco.Banco;
import modelo.personas.ClienteNatural;
import modelo.personas.ClienteEmpresarial;
import modelo.enums.TipoCuenta;
import modelo.cuentas.CuentaAhorros;
import modelo.cuentas.CuentaCorriente;
import modelo.cuentas.CuentaCredito;
import modelo.excepciones.DatoInvalidoException;
import modelo.excepciones.BancoRuntimeException;
import modelo.excepciones.SistemaBancarioException;
public class main{
   static Scanner sc = new Scanner(System.in);
        static  Banco banco = new Banco();

    public static void main(String[] args) throws DatoInvalidoException {

    Scanner sc = new Scanner(System.in);
    Banco banco = new Banco();

    int op;

    do {
        System.out.println("\n==== SISTEMA BANCARIO ====");
        System.out.println("1 - Crear cliente natural");
        System.out.println("2 - Crear cliente empresarial");
        System.out.println("3 - Listar clientes");
        System.out.println("4 - Crear cuenta");
        System.out.println("5 - Listar cuentas");
        System.out.println("6 - Depositar");
        System.out.println("7 - Retirar");
        System.out.println("8 - Transferir");
        System.out.println("9 - Ver transacciones");
        System.out.println("10 - Bloquear cuenta");
        System.out.println("11 - Desbloquear cuenta");
        System.out.println("0 - Salir");
        System.out.print("Opción: ");

        op = sc.nextInt();
        sc.nextLine();

        switch (op) {

            case 1 -> {
                try {
                    System.out.print("ID: ");
                    String id = sc.nextLine();

                    System.out.print("Nombre: ");
                    String nombre = sc.nextLine();

                    System.out.print("Apellido: ");
                    String apellido = sc.nextLine();

                    System.out.print("Email: ");
                    String email = sc.nextLine();

                    System.out.print("Año nacimiento: ");
                    int año = sc.nextInt();
                    sc.nextLine();

                    ClienteNatural c = new ClienteNatural(
                            id, nombre, apellido, email,
                            LocalDate.of(año, 1, 1)
                    );

                    banco.agregarCliente(c);
                    System.out.println("✔ Cliente creado");

                } catch (DatoInvalidoException e) {
                    System.out.println(e.getMessage());
                }
            }

            case 2 -> {
                System.out.print("ID: ");
                String id = sc.nextLine();

                System.out.print("Empresa: ");
                String nombre = sc.nextLine();

                System.out.print("Email: ");
                String email = sc.nextLine();

                ClienteEmpresarial c = new ClienteEmpresarial(id, nombre, email);
                banco.agregarCliente(c);

                System.out.println("✔ Cliente empresarial creado");
            }

            case 3 -> banco.listarClientes();

            case 4 -> {
                System.out.print("ID Cliente: ");
                String id = sc.nextLine();

                System.out.println("Tipo: 1-Ahorros 2-Corriente 3-Crédito");
                int tipo = sc.nextInt();
                sc.nextLine();

                System.out.print("Saldo inicial: ");
                double saldo = sc.nextDouble();
                sc.nextLine();

                Cuenta cuenta = null;

                switch (tipo) {
                    case 1 -> cuenta = new CuentaAhorros(saldo);
                    case 2 -> cuenta = new CuentaCorriente(saldo);
                    case 3 -> cuenta = new CuentaCredito(saldo);
                }

                banco.crearCuenta(id, cuenta);
            }

            case 5 -> banco.listarCuentas();

            case 6 -> {
                System.out.print("Cuenta: ");
                String num = sc.nextLine();

                System.out.print("Monto: ");
                double m = sc.nextDouble();
                sc.nextLine();

                banco.depositar(num, m);
            }

            case 7 -> {
                System.out.print("Cuenta: ");
                String num = sc.nextLine();

                System.out.print("Monto: ");
                double m = sc.nextDouble();
                sc.nextLine();

                banco.retirar(num, m);
            }

            case 8 -> {
                System.out.print("Origen: ");
                String o = sc.nextLine();

                System.out.print("Destino: ");
                String d = sc.nextLine();

                System.out.print("Monto: ");
                double m = sc.nextDouble();
                sc.nextLine();

                banco.transferir(o, d, m);
            }

            case 9 -> {
                System.out.print("Cuenta: ");
                String num = sc.nextLine();
                banco.verTransacciones(num);
            }

            case 10 -> {
                System.out.print("Cuenta: ");
                String num = sc.nextLine();
                banco.bloquearCuenta(num);
            }

            case 11 -> {
                System.out.print("Cuenta: ");
                String num = sc.nextLine();
                banco.desbloquearCuenta(num);
            }
        }

    } while (op != 0);

    System.out.println("Sistema finalizado");
    }
    }