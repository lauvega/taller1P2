package modelo.cuentas;

import modelo.abstractas.Cuenta;

public class CuentaCredito extends Cuenta {

    public CuentaCredito(double saldo) {
        super(saldo);
    }

    @Override
    public double calcularInteres() {
        return saldo * 0.03;
    }
}

