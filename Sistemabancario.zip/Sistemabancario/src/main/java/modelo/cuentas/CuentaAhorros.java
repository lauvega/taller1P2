package modelo.cuentas;

import modelo.abstractas.Cuenta;

public class CuentaAhorros extends Cuenta {

    public CuentaAhorros(double saldo) {
        super(saldo);
    }

    @Override
    public double calcularInteres() {
        return saldo * 0.02;
    }
}