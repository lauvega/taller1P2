package modelo.cuentas;

import modelo.abstractas.Cuenta;

public class CuentaCorriente extends Cuenta {

    public CuentaCorriente(double saldo) {
        super(saldo);
    }

    @Override
    public double calcularInteres() {
        return saldo * 0.01;
    }
}

    

