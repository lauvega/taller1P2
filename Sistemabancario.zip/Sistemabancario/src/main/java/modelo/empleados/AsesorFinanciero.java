package modelo.empleados;

import modelo.abstractas.Empleado;

public class AsesorFinanciero extends Empleado {

    public AsesorFinanciero(String nombre, double salario) {
        super(nombre, salario);
    }

    @Override
    public double calcularSalario() {
        return salario + 500;
    }
}