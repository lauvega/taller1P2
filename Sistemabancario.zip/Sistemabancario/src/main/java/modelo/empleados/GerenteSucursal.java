package modelo.empleados;

import modelo.abstractas.Empleado;

public class GerenteSucursal extends Empleado {

    public GerenteSucursal(String nombre, double salario) {
        super(nombre, salario);
    }

    @Override
    public double calcularSalario() {
        return salario + 1000;
    }
}
