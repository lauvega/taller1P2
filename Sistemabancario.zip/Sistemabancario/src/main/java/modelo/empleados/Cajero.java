package modelo.empleados;

import modelo.abstractas.Empleado;

public class Cajero extends Empleado {

    public Cajero(String nombre, double salario) {
        super(nombre, salario);
    }

    @Override
    public double calcularSalario() {
        return salario;
    }
}