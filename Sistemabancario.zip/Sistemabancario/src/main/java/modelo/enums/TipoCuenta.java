package modelo.enums;

public enum TipoCuenta {
    AHORROS,
    CORRIENTE,
    CREDITO
}
