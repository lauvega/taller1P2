package modelo.enums;

public enum EstadoTransaccion {
    PENDIENTE,
    APROBADA,
    RECHAZADA
}
