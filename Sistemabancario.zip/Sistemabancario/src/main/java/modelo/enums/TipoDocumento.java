package modelo.enums;

public enum TipoDocumento {
    CC,
    TI,
    CE,
    PASAPORTE
}