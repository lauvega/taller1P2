package modelo.interfaces;

public interface Auditable {

    void registrarAuditoria(String mensaje);

}