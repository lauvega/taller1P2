package modelo.banco;

import modelo.personas.ClienteNatural;
import modelo.personas.ClienteEmpresarial;
import modelo.abstractas.Cuenta;
import modelo.excepciones.SistemaBancarioException;
import modelo.abstractas.Persona;
import modelo.excepciones.DatoInvalidoException;
public class Banco {

    // ===== CLIENTES =====
    private ClienteNatural[] client = new ClienteNatural[10];
    private int contador = 0;

    private ClienteEmpresarial[] clientes = new ClienteEmpresarial[10];
    private int cont = 0;

    public void agregarCliente(ClienteNatural cliente) {
        if (contador < 10) {
            client[contador++] = cliente;
        }
    }

    public void agregarCliente(ClienteEmpresarial cl) {
        if (cont < 10) {
            clientes[cont++] = cl;
        }
    }

    public void listarClientes() {
        System.out.println("=== CLIENTES NATURALES ===");
        for (ClienteNatural c : client) {
            if (c != null) {
                System.out.println(c);
            }
        }

        System.out.println("=== CLIENTES EMPRESARIALES ===");
        for (ClienteEmpresarial c : clientes) {
            if (c != null) {
                System.out.println(c);
            }
        }
    }
    public void verTransacciones(String numeroCuenta) {
    int i = buscarCuentaIndex(numeroCuenta);
    if (i != -1) {
        cuentas[i].mostrarTransacciones();
    } else {
        System.out.println("Cuenta no encontrada");
    }
}

    // ===== CUENTAS =====
    private Cuenta[] cuentas = new Cuenta[20];
    private String[] numeros = new String[20];
    private int contCuentas = 0;

    public void crearCuenta(String idCliente, Cuenta cuenta) throws DatoInvalidoException {
        for (ClienteNatural c : client) {
        if (c != null && c.getId().equals(idCliente)) {
            c.agregarCuenta(cuenta);
            cuentas[contCuentas] = cuenta;
            numeros[contCuentas] = "C" + contCuentas;
            contCuentas++;
            return;
        }
    }
         for (ClienteEmpresarial c : clientes) {
        if (c != null && c.getId().equals(idCliente)) {
            c.agregarCuenta(cuenta);
            cuentas[contCuentas] = cuenta;
            numeros[contCuentas] = "C" + contCuentas;
            contCuentas++;
            return;
        }
    }
         System.out.println("Cliente no encontrado");
    }

    public void listarCuentas() {
    for (int i = 0; i < contCuentas; i++) {
        System.out.println(
            "Cuenta: " + numeros[i] +
            " | Saldo: " + cuentas[i].getSaldo()
        );
    }
}

    private int buscarCuentaIndex(String numero) {
        for (int i = 0; i < contCuentas; i++) {
            if (numeros[i].equals(numero)) {
                return i;
            }
        }
        return -1;
    }

    // ===== TRANSACCIONES =====
    public void depositar(String numero, double monto) {
        int i = buscarCuentaIndex(numero);
        if (i != -1) {
            try {
                cuentas[i].depositar(monto);
            } catch (SistemaBancarioException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    public void retirar(String numero, double monto) {
        int i = buscarCuentaIndex(numero);
        if (i != -1) {
            try {
                cuentas[i].retirar(monto);
            } catch (SistemaBancarioException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    public void transferir(String origen, String destino, double monto) {
        int i = buscarCuentaIndex(origen);
        int j = buscarCuentaIndex(destino);

        if (i != -1 && j != -1) {
            try {
                cuentas[i].retirar(monto);
                cuentas[j].depositar(monto);
            } catch (SistemaBancarioException e) {
                System.out.println(e.getMessage());
            }
        }
    }
    public void bloquearCuenta(String numero) {
    int i = buscarCuentaIndex(numero);
    if (i != -1) {
        cuentas[i].bloquear();
        System.out.println("Cuenta bloqueada");
    }
}

public void desbloquearCuenta(String numero) {
    int i = buscarCuentaIndex(numero);
    if (i != -1) {
        cuentas[i].desbloquear();
        System.out.println("Cuenta desbloqueada");
    }
}
}