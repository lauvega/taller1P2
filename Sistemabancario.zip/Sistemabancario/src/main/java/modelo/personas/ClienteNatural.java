package modelo.personas;

import java.time.LocalDate;
import modelo.abstractas.Persona;
import modelo.abstractas.Cuenta;
import modelo.excepciones.DatoInvalidoException;

public class ClienteNatural extends Persona {

    private Cuenta[] cuentas = new Cuenta[5];
    private int contador = 0;
    private int contCuentas;

    public ClienteNatural(String nombre, String Id, String apellido, String email, LocalDate of) throws DatoInvalidoException {
        super(nombre, Id);
    }
    public Cuenta[] getCuentas() {
    Cuenta[] copia = new Cuenta[contCuentas];
    System.arraycopy(cuentas, 0, copia, 0, contCuentas);
    return copia;
}


    public void agregarCuenta(Cuenta cuenta) throws DatoInvalidoException {
        if (contador >= 5) {
            throw new DatoInvalidoException("Máximo 5 cuentas");
        }
        cuentas[contador++] = cuenta;
    }

    public String getId() {
        return documento;
    }
}