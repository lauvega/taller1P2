package modelo.personas;

import modelo.abstractas.Persona;
import modelo.excepciones.DatoInvalidoException;
import modelo.abstractas.Cuenta;

public class ClienteEmpresarial extends Persona {
    private Cuenta[]cuentas=new Cuenta[5];
    private int contCuentas=0;
    public ClienteEmpresarial(String nombre, String Id, String email) throws DatoInvalidoException {
        super(nombre, Id);
    }
    public void agregarCuenta(Cuenta cuenta) {
    if (contCuentas < 5) {
        cuentas[contCuentas++] = cuenta;
    } else {
        System.out.println("Máximo de cuentas alcanzado");
    }
}
     public String getId() {
        return documento;
    }
     public Cuenta[] getCuentas() {
    Cuenta[] copia = new Cuenta[contCuentas];
    System.arraycopy(cuentas, 0, copia, 0, contCuentas);
    return copia;
     }
}