
package modelo.abstractas;

import modelo.excepciones.DatoInvalidoException;

public abstract class Persona {

    protected String nombre;
    protected String documento;

    public Persona(String nombre, String documento) throws DatoInvalidoException {
        setNombre(nombre);
        setDocumento(documento);
    }

    public void setNombre(String nombre) throws DatoInvalidoException {
        if (nombre == null || nombre.isEmpty()) {
            throw new DatoInvalidoException("Nombre inválido");
        }
        this.nombre = nombre;
    }

    public void setDocumento(String documento) throws DatoInvalidoException {
        if (documento == null || documento.isEmpty()) {
            throw new DatoInvalidoException("Documento inválido");
        }
        this.documento = documento;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDocumento() {
        return documento;
    }
}