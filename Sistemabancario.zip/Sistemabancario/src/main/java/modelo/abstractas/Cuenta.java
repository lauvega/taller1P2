
package modelo.abstractas;

import modelo.interfaces.Transaccionable;
import modelo.excepciones.SistemaBancarioException;

public abstract class Cuenta implements Transaccionable {

    protected double saldo;
    protected double[] transacciones = new double[20];
    protected int contador = 0;
    protected boolean activa=true;

    public Cuenta(double saldo) {
        this.saldo = saldo;
    }

    @Override
    public void depositar(double monto) throws SistemaBancarioException {
       if (!activa) {
    throw new SistemaBancarioException("Cuenta bloqueada");
        }
    }

    @Override
    public void retirar(double monto) throws SistemaBancarioException {
        if (!activa) {
          throw new SistemaBancarioException("Cuenta bloqueada");
         }
    }

    private void registrar(double monto) {
        if (contador < 20) {
            transacciones[contador++] = monto;
        }
    }

    public abstract double calcularInteres();
    public void mostrarTransacciones() {
    System.out.println("=== Historial de transacciones ===");
    for (int i = 0; i < contador; i++) {
        System.out.println(transacciones[i]);
    }
}
    public void bloquear() {
    activa = false;
}

public void desbloquear() {
    activa = true;
}

public double getSaldo() {
    return saldo;
}
}